# Formed-Movement Causal Audit

Date: 2026-09-13

## Question
When formed dots fail to move before dissolution, is that because:
- movement energy is unavailable, or
- the frozen formed-state score actually selects staying?

## Groups
- transported-reformation success seeds: 44
- transported-reformation failure seeds: 20
- failure seeds with zero transported dissolution at all: 14
- failure seeds that did create transported dissolution but never reused it: 6

## Aggregate formed decisions

Success group:
- formed decisions: 9850
- actual moves: 104 (1.056%)
- move selected but blocked by insufficient energy: 8449 (85.777%)
- stay selected by score/tie rule: 1297 (13.168%)

Failure group:
- formed decisions: 5227
- actual moves: 13 (0.249%)
- move selected but blocked by insufficient energy: 4374 (83.681%)
- stay selected by score/tie rule: 840 (16.070%)

## Geometry/score relationship

Failure group:
- some move strictly outscored stay: 4387
- best move tied stay: 0
- stay strictly outscored all moves: 840
- formed decisions with energy <1 after maintenance: 5011

## Interpretation boundary
This audit does not alter the movement rule. It identifies whether non-transport is caused primarily by energy inability or by the existing local score/tie structure.
