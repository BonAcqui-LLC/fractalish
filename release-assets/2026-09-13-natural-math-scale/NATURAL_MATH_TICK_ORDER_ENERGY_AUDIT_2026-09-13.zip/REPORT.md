# Tick-Order Energy Audit

Date: 2026-09-13

The first two instrumentation attempts were rejected because they did not reproduce the frozen runner exactly.
This accepted audit instruments a copy of the exact frozen source and matched the original event hash, q counters, and quarter-work totals for all 64 seeds.

## Question

Does charging maintenance before movement remove a movement that was locally selected and affordable at the beginning of the same tick?

ORDER_BLOCKED means:
- the formed dot's frozen movement score selected a move;
- pre-maintenance energy was at least 1;
- maintenance consumed the remaining movement energy;
- the selected move therefore did not execute.

No state transition was changed.

## Transported-success group (44 seeds)

- formed ticks audited: 27232
- movement selected before maintenance: 19113
- order-blocked moves: 8449 (44.206% of selected moves)
- actual formed moves: 104
- maintenance dissolutions: 17382

## Transported-failure group (20 seeds)

- formed ticks audited: 14503
- movement selected before maintenance: 10201
- order-blocked moves: 4374 (42.878% of selected moves)
- actual formed moves: 13
- maintenance dissolutions: 9276

Failure seeds with >=1 order-blocked move: 20/20
Success seeds with >=1 order-blocked move: 44/44

## Interpretation boundary

This audit establishes whether tick order suppresses a move that the same formed dot had already selected and could afford before maintenance. It does not test a replacement priority rule.
