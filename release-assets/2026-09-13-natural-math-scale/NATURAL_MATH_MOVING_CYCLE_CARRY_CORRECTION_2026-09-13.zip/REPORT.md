# Carry/Conjunction Correction — Results

Validity: **PASS**
Correction: **PASS**
Full cycle: **FAIL**

## Cycle gates
- C1_formations_positive: PASS
- C2_work_positive: PASS
- C3_dissolutions_positive: PASS
- C4_median_reforms_at_least8: PASS
- C5_48_seeds_independent_reform: PASS
- C6_48_seeds_transported_reform: FAIL
- C7_48_seeds_late_work: PASS
- C8_final_quarter_work_positive: PASS
- C9_final_qtr_at_least_quarter_first: PASS
- C10_median_unique_after64_gt1: PASS

## Correction gates
- K1_final_qtr_work_gt_baseline: PASS
- K2_reforms_gt_baseline: PASS
- K3_independent_gt_baseline: PASS
- K4_transported_gt_baseline: PASS

## Medians

| condition | work | forms | dissolutions | reforms | independent | transported | Q1 | Q4 | late-work seeds | unique positions after64 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CARRY_CONJUNCTION | 122.0 | 421.0 | 420.0 | 381.5 | 181.5 | 1.0 | 47.5 | 22.5 | 64 | 60.25 |
| NO_CARRY_BASELINE | 17.0 | 12.0 | 12.0 | 6.0 | 0.0 | 0.0 | 17.0 | 0.0 | 13 | 1.0 |

No post-result tuning was performed.
