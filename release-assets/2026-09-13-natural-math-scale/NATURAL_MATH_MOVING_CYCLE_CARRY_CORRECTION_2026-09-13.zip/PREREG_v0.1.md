# Moving Cycle Carry/Conjunction Correction — Preregistration v0.1

Status: FROZEN BEFORE IMPLEMENTATION
Date: 2026-09-13

## Runs
64 seeds x 2 conditions x 512 ticks.
Every run exact-replayed.

## Validity gates
V1 material conservation every tick.
V2 energy conservation every tick.
V3 exact replay every run.
V4 no negative material/energy/cargo.
V5 cargo never exceeds 3.
V6 every formation has matching addressed trace + cargo/material 3 + energy 3.
V7 every dissolution-trace reformation references a prior real dissolution.

## Cycle gates: CARRY_CONJUNCTION
C1 median formations > 0.
C2 median useful work > 0.
C3 median dissolutions > 0.
C4 median dissolution-trace reformations >= 8.
C5 >=48/64 seeds have >=1 contributor-independent reformation.
C6 >=48/64 seeds have >=1 transported-substrate reformation.
C7 >=48/64 seeds have useful work after tick 128.
C8 median final-quarter work > 0.
C9 median final-quarter work >=25% median first-quarter work.
C10 median distinct positions per agent after tick 64 > 1.

## Causal correction comparison
K1 median final-quarter work > NO_CARRY_BASELINE.
K2 median dissolution-trace reformations > NO_CARRY_BASELINE.
K3 median contributor-independent reformations > NO_CARRY_BASELINE.
K4 median transported-substrate reformations > NO_CARRY_BASELINE.

Do not tune after result.
