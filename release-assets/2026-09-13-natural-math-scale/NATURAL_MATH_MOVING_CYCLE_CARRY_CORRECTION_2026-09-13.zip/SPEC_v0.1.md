# Natural Math Moving Cycle — Carry/Conjunction Correction v0.1

Status: FROZEN BEFORE IMPLEMENTATION
Date: 2026-09-13

## Why this correction exists

The prior movement audits showed a structural impossibility:
- addressed trace could be at one cell;
- sufficient free material could be at another visible cell;
- a dot could move between the cells;
- but material could not move with the dot.

Therefore changing direction alone could not generally complete the existing
trace + material + energy conjunction.

This correction adds no planner, curiosity bonus, global map, learned policy,
future knowledge, or broadcast information.

It gives the already-mobile dot one bounded physical cargo field so movement
can actually transport the material it locally encounters.

## World

Unchanged:
- 17x17 toroidal integer lattice
- 18 mobile dots
- 3 relation classes
- 512 ticks
- 64 deterministic seeds
- same initial positions, headings, energy
- same initial sparse free material and addressed traces
- same deterministic external material feed
- same deterministic local energy field
- same deterministic demand field
- same lifetime, maintenance, work, dissolution, recovery, and trace writing

## Added physical state

Each dot has integer cargo M_c in {0,1,2,3}.
Initial cargo = 0.
Cargo capacity = 3, exactly one formation's material requirement.

Cargo is ordinary conserved material.
It is not information.

An unformed dot may pick up free material from its current cell up to capacity.
Pickup has no global search and no remote transfer.

## Corrected movement decision

Every tick is a new decision.
All four neighboring cells plus stay are available.

For an unformed dot:

If cargo < 3:
- candidate score = 2 * min(3-cargo, free_material_at_candidate)
- +1 if the candidate is an active energy-input cell AND dot energy < 3.
- matching trace contributes 0 while material is still missing.

If cargo >= 3:
- candidate score = +4 for a matching addressed trace at that candidate cell.
- +1 if candidate is an active energy-input cell AND dot energy < 3.

For formed dots, the prior score is unchanged:
- +4 if candidate demand matches relation
- +1 if candidate is an active energy-input cell.

Tie order:
forward > left > right > backward > stay.

Movement costs 1 energy.
Stay costs 0.
Heading changes only on movement.

This uses only current local state and the existing formation requirements.

## Pickup order

For each unformed dot:
1. before movement, pick up available free material at its current cell up to cargo 3;
2. evaluate movement;
3. move if selected and affordable;
4. after movement, pick up available free material at the arrived cell up to cargo 3.

Dots are processed in ascending id, so competing pickups are deterministic.

## Formation

An unformed dot forms only if:
- current cell has matching addressed trace;
- cargo >= 3;
- dot energy >= 3.

Formation consumes:
- 3 cargo material into embedded structure;
- 3 energy.

Cargo becomes 0.
Embedded material becomes 3.
Lifetime = 7.

## Dissolution

Unchanged:
- embedded 3 -> 2 free material at current cell + 1 conversion loss;
- writes addressed DISSOLUTION trace at current cell;
- dot becomes unformed with cargo 0.

## Conditions

CARRY_CONJUNCTION:
- bounded cargo and unmet-requirement movement rule above.

NO_CARRY_BASELINE:
- exact prior corrected-movement behavior: all four neighbors + stay,
  trace +4, material-ready +2, energy patch +1, no cargo.
This is included only as the direct causal control.

## Conservation

Material:
initial free M + external M feed
= free-cell M + cargo M + embedded M + conversion loss.

Energy:
initial E + external E feed
= agent E + movement + formation + maintenance + work costs.

## Question

Does allowing actual local movement of the already-required material let the
moving system execute the previously blocked cycle without any global planner
or new information mechanism?
