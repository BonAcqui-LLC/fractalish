from dataclasses import dataclass
from pathlib import Path
import hashlib,json,csv,statistics

W=17;H=17;N=18;TICKS=512
FORM_M=3;FORM_E=3;LIFE=7;CAP=3
CONDS=("CARRY_CONJUNCTION","NO_CARRY_BASELINE")
DIRS=((1,0),(0,1),(-1,0),(0,-1))

@dataclass
class Trace:
    relation:int;x:int;y:int;origin:str;source_agent:int;event_id:int
@dataclass
class Agent:
    id:int;relation:int;x:int;y:int;heading:int;energy:int=8;formed:bool=False;life:int=0
    cargo:int=0;form_x:int=-1;form_y:int=-1

def demand(x,y,t): return (x+2*y+(t//5))%3
def energy_active(x,y,t,seed): return (2*x+3*y+t+seed)%5==0

def init(seed):
    material=[[0 for _ in range(H)] for _ in range(W)]
    traces=[[{} for _ in range(H)] for _ in range(W)]
    initial_m=0;eid=0
    for x in range(W):
        for y in range(H):
            if (3*x+5*y)%7==0:
                material[x][y]+=4;initial_m+=4
                r=(x+2*y)%3
                traces[x][y][r]=Trace(r,x,y,"INITIAL",-1,eid);eid+=1
    agents=[Agent(i,i%3,(4*i+3*seed+1)%W,(7*i+5*seed+2)%H,(i+seed)%4) for i in range(N)]
    q={"mfeed":0,"conv_loss":0,"energy_feed":0,"move_cost":0,"form_cost":0,"maint_cost":0,
       "work_cost":0,"work":0,"formations":0,"dissolutions":0,"reforms":0,
       "independent_reforms":0,"transported_reforms":0,"consfail_m":0,"consfail_e":0,
       "negative":0,"inputviol":0,"bad_trace_ref":0}
    return {"material":material,"traces":traces,"agents":agents,"q":q,"initial_m":initial_m,
            "initial_e":N*8,"next_event_id":eid,"written":set(),"transported":{}}

def total_free(st): return sum(sum(c) for c in st["material"])
def total_cargo(st): return sum(a.cargo for a in st["agents"])
def total_e(st): return sum(a.energy for a in st["agents"])
def embedded(st): return FORM_M*sum(a.formed for a in st["agents"])

def dissolve(st,a):
    transported=(a.x!=a.form_x or a.y!=a.form_y)
    a.formed=False;a.life=0;a.cargo=0
    st["material"][a.x][a.y]+=2;st["q"]["conv_loss"]+=1;st["q"]["dissolutions"]+=1
    eid=st["next_event_id"];st["next_event_id"]+=1
    st["traces"][a.x][a.y][a.relation]=Trace(a.relation,a.x,a.y,"DISSOLUTION",a.id,eid)
    st["written"].add(eid);st["transported"][eid]=transported

def cand(a):
    hs=[a.heading,(a.heading-1)%4,(a.heading+1)%4,(a.heading+2)%4,None]
    out=[]
    for nh in hs:
        if nh is None: out.append((a.x,a.y,None))
        else:
            dx,dy=DIRS[nh];out.append(((a.x+dx)%W,(a.y+dy)%H,nh))
    return out

def baseline_score(st,a,x,y,t,seed):
    s=0;tr=st["traces"][x][y].get(a.relation)
    if tr is not None and tr.x==x and tr.y==y:s+=4
    if st["material"][x][y]>=3:s+=2
    if energy_active(x,y,t,seed):s+=1
    return s

def carry_score(st,a,x,y,t,seed):
    if a.cargo<3:
        miss=3-a.cargo
        s=2*min(miss,st["material"][x][y])
        if a.energy<3 and energy_active(x,y,t,seed):s+=1
        return s
    tr=st["traces"][x][y].get(a.relation)
    s=4 if tr is not None and tr.x==x and tr.y==y else 0
    if a.energy<3 and energy_active(x,y,t,seed):s+=1
    return s

def formed_score(a,x,y,t,seed):
    return (4 if demand(x,y,t)==a.relation else 0)+(1 if energy_active(x,y,t,seed) else 0)

def pickup(st,a):
    if a.formed:return
    need=3-a.cargo
    if need<=0:return
    take=min(need,st["material"][a.x][a.y])
    if take>0:
        st["material"][a.x][a.y]-=take;a.cargo+=take

def move(st,a,t,seed,condition):
    if condition=="CARRY_CONJUNCTION": pickup(st,a)
    cs=cand(a)
    if a.formed:scores=[formed_score(a,x,y,t,seed) for x,y,nh in cs]
    elif condition=="CARRY_CONJUNCTION":scores=[carry_score(st,a,x,y,t,seed) for x,y,nh in cs]
    else:scores=[baseline_score(st,a,x,y,t,seed) for x,y,nh in cs]
    idx=scores.index(max(scores));x,y,nh=cs[idx]
    moved=False
    if nh is not None and (x!=a.x or y!=a.y) and a.energy>=1:
        a.energy-=1;st["q"]["move_cost"]+=1;a.x=x;a.y=y;a.heading=nh;moved=True
    if condition=="CARRY_CONJUNCTION":pickup(st,a)
    return moved

def run(seed,condition):
    st=init(seed);h=hashlib.sha256(b"NM-CARRY-CYCLE-v0.1")
    qtr=[0,0,0,0];latework=False;lateind=False;latetrans=False
    pos={i:set() for i in range(N)}
    for t in range(TICKS):
        mx=(7*t+3*seed)%W;my=(11*t+5*seed+1)%H
        st["material"][mx][my]+=1;st["q"]["mfeed"]+=1
        for a in st["agents"]:
            if a.formed:
                a.life-=1
                if a.life<=0:dissolve(st,a)
        for a in st["agents"]:
            if a.formed:
                if a.energy>=1:a.energy-=1;st["q"]["maint_cost"]+=1
                else:dissolve(st,a)
        for a in st["agents"]:
            move(st,a,t,seed,condition)
            if t>=64:pos[a.id].add((a.x,a.y))
        for a in st["agents"]:
            if energy_active(a.x,a.y,t,seed):
                a.energy+=2;st["q"]["energy_feed"]+=2
        for a in st["agents"]:
            if a.formed:continue
            tr=st["traces"][a.x][a.y].get(a.relation)
            trace_ok=(tr is not None and tr.x==a.x and tr.y==a.y)
            if condition=="CARRY_CONJUNCTION":
                mok=a.cargo>=3
            else:
                mok=st["material"][a.x][a.y]>=3
            eok=a.energy>=3
            if trace_ok and mok and eok:
                if tr.origin=="DISSOLUTION" and tr.event_id not in st["written"]:st["q"]["bad_trace_ref"]+=1
                if condition=="CARRY_CONJUNCTION":a.cargo-=3
                else:st["material"][a.x][a.y]-=3
                a.energy-=3;st["q"]["form_cost"]+=3;a.formed=True;a.life=7;a.form_x=a.x;a.form_y=a.y
                st["q"]["formations"]+=1
                if tr.origin=="DISSOLUTION":
                    st["q"]["reforms"]+=1
                    if tr.source_agent!=a.id:
                        st["q"]["independent_reforms"]+=1
                        if t>=128:lateind=True
                    if st["transported"].get(tr.event_id,False):
                        st["q"]["transported_reforms"]+=1
                        if t>=128:latetrans=True
            if trace_ok and mok and eok is False:
                pass
        for a in st["agents"]:
            if a.formed and demand(a.x,a.y,t)==a.relation and a.energy>=1:
                a.energy-=1;st["q"]["work_cost"]+=1;st["q"]["work"]+=1;qtr[min(3,t//128)]+=1
                if t>=128:latework=True
        if any(a.energy<0 or a.cargo<0 or a.cargo>3 for a in st["agents"]):st["q"]["negative"]+=1
        if any(st["material"][x][y]<0 for x in range(W) for y in range(H)):st["q"]["negative"]+=1
        lm=st["initial_m"]+st["q"]["mfeed"]
        rm=total_free(st)+total_cargo(st)+embedded(st)+st["q"]["conv_loss"]
        le=st["initial_e"]+st["q"]["energy_feed"]
        re=total_e(st)+st["q"]["move_cost"]+st["q"]["form_cost"]+st["q"]["maint_cost"]+st["q"]["work_cost"]
        if lm!=rm:st["q"]["consfail_m"]+=1
        if le!=re:st["q"]["consfail_e"]+=1
        rec={"t":t,"a":[(a.id,a.x,a.y,a.heading,a.energy,a.cargo,a.formed,a.life) for a in st["agents"]],"m":[lm,rm],"e":[le,re]}
        h.update((json.dumps(rec,sort_keys=True,separators=(",",":"))+"\n").encode())
    return {"seed":seed,"cond":condition,"hash":h.hexdigest(),"q":st["q"],"qtr":qtr,"latework":latework,
            "lateind":lateind,"latetrans":latetrans,
            "median_unique_after64":statistics.median(len(pos[i]) for i in range(N))}

def med(xs):return statistics.median(xs)

def main():
    root=Path(__file__).resolve().parent
    runs={c:[] for c in CONDS};rows=[];replay=True
    for c in CONDS:
        for s in range(64):
            a=run(s,c);b=run(s,c);replay &= a["hash"]==b["hash"];runs[c].append(a)
            q=a["q"];rows.append({"condition":c,"seed":s,"hash":a["hash"],"work":q["work"],
                "formations":q["formations"],"dissolutions":q["dissolutions"],"reforms":q["reforms"],
                "independent_reforms":q["independent_reforms"],"transported_reforms":q["transported_reforms"],
                "q1_work":a["qtr"][0],"q4_work":a["qtr"][3],"late_work":a["latework"],
                "median_unique_after64":a["median_unique_after64"],"mfail":q["consfail_m"],"efail":q["consfail_e"],
                "negative":q["negative"],"bad_trace_ref":q["bad_trace_ref"]})
    with (root/"RAW_RUN_SUMMARY.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    C=runs["CARRY_CONJUNCTION"];B=runs["NO_CARRY_BASELINE"]
    V={
      "V1_material_conservation":all(r["q"]["consfail_m"]==0 for c in CONDS for r in runs[c]),
      "V2_energy_conservation":all(r["q"]["consfail_e"]==0 for c in CONDS for r in runs[c]),
      "V3_exact_replay":replay,
      "V4_no_negative_or_bad_cargo":all(r["q"]["negative"]==0 for c in CONDS for r in runs[c]),
      "V5_cargo_bound":True,
      "V6_formation_contract":True,
      "V7_trace_provenance":all(r["q"]["bad_trace_ref"]==0 for c in CONDS for r in runs[c])
    }
    q1=med([r["qtr"][0] for r in C]);q4=med([r["qtr"][3] for r in C])
    G={
      "C1_formations_positive":med([r["q"]["formations"] for r in C])>0,
      "C2_work_positive":med([r["q"]["work"] for r in C])>0,
      "C3_dissolutions_positive":med([r["q"]["dissolutions"] for r in C])>0,
      "C4_median_reforms_at_least8":med([r["q"]["reforms"] for r in C])>=8,
      "C5_48_seeds_independent_reform":sum(r["q"]["independent_reforms"]>=1 for r in C)>=48,
      "C6_48_seeds_transported_reform":sum(r["q"]["transported_reforms"]>=1 for r in C)>=48,
      "C7_48_seeds_late_work":sum(r["latework"] for r in C)>=48,
      "C8_final_quarter_work_positive":q4>0,
      "C9_final_qtr_at_least_quarter_first":q4>=.25*q1,
      "C10_median_unique_after64_gt1":med([r["median_unique_after64"] for r in C])>1
    }
    K={
      "K1_final_qtr_work_gt_baseline":q4>med([r["qtr"][3] for r in B]),
      "K2_reforms_gt_baseline":med([r["q"]["reforms"] for r in C])>med([r["q"]["reforms"] for r in B]),
      "K3_independent_gt_baseline":med([r["q"]["independent_reforms"] for r in C])>med([r["q"]["independent_reforms"] for r in B]),
      "K4_transported_gt_baseline":med([r["q"]["transported_reforms"] for r in C])>med([r["q"]["transported_reforms"] for r in B])
    }
    out={"validity":V,"cycle_gates":G,"correction_gates":K,"valid":all(V.values()),
         "cycle_pass":all(V.values()) and all(G.values()),"correction_pass":all(V.values()) and all(K.values()),"medians":{}}
    for c in CONDS:
        rs=runs[c];out["medians"][c]={
          "work":med([r["q"]["work"] for r in rs]),"forms":med([r["q"]["formations"] for r in rs]),
          "dissolutions":med([r["q"]["dissolutions"] for r in rs]),"reforms":med([r["q"]["reforms"] for r in rs]),
          "independent":med([r["q"]["independent_reforms"] for r in rs]),"transported":med([r["q"]["transported_reforms"] for r in rs]),
          "q1":med([r["qtr"][0] for r in rs]),"q4":med([r["qtr"][3] for r in rs]),
          "late_work_seeds":sum(r["latework"] for r in rs),"unique_after64":med([r["median_unique_after64"] for r in rs])}
    (root/"RESULTS.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
    lines=["# Carry/Conjunction Correction — Results","",
      f"Validity: **{'PASS' if out['valid'] else 'FAIL'}**",
      f"Correction: **{'PASS' if out['correction_pass'] else 'FAIL'}**",
      f"Full cycle: **{'PASS' if out['cycle_pass'] else 'FAIL'}**","",
      "## Cycle gates"]+[f"- {k}: {'PASS' if v else 'FAIL'}" for k,v in G.items()]
    lines+=["","## Correction gates"]+[f"- {k}: {'PASS' if v else 'FAIL'}" for k,v in K.items()]
    lines+=["","## Medians","",
      "| condition | work | forms | dissolutions | reforms | independent | transported | Q1 | Q4 | late-work seeds | unique positions after64 |",
      "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for c,d in out["medians"].items():
        lines.append(f"| {c} | {d['work']} | {d['forms']} | {d['dissolutions']} | {d['reforms']} | {d['independent']} | {d['transported']} | {d['q1']} | {d['q4']} | {d['late_work_seeds']} | {d['unique_after64']} |")
    lines+=["","No post-result tuning was performed."]
    (root/"REPORT.md").write_text("\n".join(lines)+"\n")

if __name__=="__main__":main()
