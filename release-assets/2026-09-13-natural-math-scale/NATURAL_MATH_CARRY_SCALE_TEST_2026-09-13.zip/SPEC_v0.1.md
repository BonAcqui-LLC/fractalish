# Frozen Carry-Cycle Scale Test v0.1
Status: FROZEN BEFORE IMPLEMENTATION
Date: 2026-09-13

Frozen local carry mechanism. Scales s={1,2,3}.
For scale s: side=17s; agents=18s^2; horizon=512s; lifetime=7s;
material-feed events/tick=s^2; observation windows scale with horizon.
Movement stays one edge/tick, so reachable distance/horizon scales with world side.
Local costs, cargo=3, formation rule, traces, scoring, tie-breaks unchanged.
64 deterministic seeds per scale. No post-result tuning.
