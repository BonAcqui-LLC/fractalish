
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,csv,statistics
DIRS=((1,0),(0,1),(-1,0),(0,-1))
FORM_M=3

@dataclass
class Trace:
    relation:int;x:int;y:int;origin:str;source_agent:int;event_id:int
@dataclass
class Agent:
    id:int;relation:int;x:int;y:int;heading:int;energy:int=8;formed:bool=False;life:int=0
    cargo:int=0;form_x:int=-1;form_y:int=-1

def demand(x,y,t): return (x+2*y+(t//5))%3
def energy_active(x,y,t,seed): return (2*x+3*y+t+seed)%5==0
def pars(s): return 17*s,17*s,18*s*s,512*s,7*s,s*s

def init(seed,s):
    W,H,N,T,L,F=pars(s)
    material=[[0]*H for _ in range(W)]
    traces=[[{} for _ in range(H)] for _ in range(W)]
    im=0;eid=0
    for x in range(W):
        for y in range(H):
            if (3*x+5*y)%7==0:
                material[x][y]=4;im+=4;r=(x+2*y)%3
                traces[x][y][r]=Trace(r,x,y,"INITIAL",-1,eid);eid+=1
    agents=[Agent(i,i%3,(4*i+3*seed+1)%W,(7*i+5*seed+2)%H,(i+seed)%4) for i in range(N)]
    q={k:0 for k in ["mfeed","conv_loss","energy_feed","move_cost","form_cost","maint_cost","work_cost",
        "work","formations","dissolutions","reforms","independent_reforms","transported_reforms",
        "consfail_m","consfail_e","negative","bad_trace_ref"]}
    return dict(material=material,traces=traces,agents=agents,q=q,initial_m=im,initial_e=N*8,
                next_event_id=eid,written=set(),transported={})

def tfree(st): return sum(map(sum,st["material"]))
def tcargo(st): return sum(a.cargo for a in st["agents"])
def tenergy(st): return sum(a.energy for a in st["agents"])
def embedded(st): return 3*sum(a.formed for a in st["agents"])

def dissolve(st,a):
    trans=(a.x!=a.form_x or a.y!=a.form_y)
    a.formed=False;a.life=0;a.cargo=0
    st["material"][a.x][a.y]+=2;st["q"]["conv_loss"]+=1;st["q"]["dissolutions"]+=1
    eid=st["next_event_id"];st["next_event_id"]+=1
    st["traces"][a.x][a.y][a.relation]=Trace(a.relation,a.x,a.y,"DISSOLUTION",a.id,eid)
    st["written"].add(eid);st["transported"][eid]=trans

def candidates(a,W,H):
    hs=[a.heading,(a.heading-1)%4,(a.heading+1)%4,(a.heading+2)%4,None]
    out=[]
    for h in hs:
        if h is None: out.append((a.x,a.y,None))
        else:
            dx,dy=DIRS[h];out.append(((a.x+dx)%W,(a.y+dy)%H,h))
    return out

def pickup(st,a):
    if a.formed:return
    take=min(3-a.cargo,st["material"][a.x][a.y])
    if take>0: st["material"][a.x][a.y]-=take;a.cargo+=take

def score(st,a,x,y,t,seed):
    if a.formed:
        return (4 if demand(x,y,t)==a.relation else 0)+(1 if energy_active(x,y,t,seed) else 0)
    if a.cargo<3:
        s=2*min(3-a.cargo,st["material"][x][y])
        if a.energy<3 and energy_active(x,y,t,seed):s+=1
        return s
    tr=st["traces"][x][y].get(a.relation)
    s=4 if tr and tr.x==x and tr.y==y else 0
    if a.energy<3 and energy_active(x,y,t,seed):s+=1
    return s

def move(st,a,t,seed,W,H):
    pickup(st,a)
    cs=candidates(a,W,H);scores=[score(st,a,x,y,t,seed) for x,y,h in cs]
    x,y,h=cs[scores.index(max(scores))]
    moved=False
    if h is not None and a.energy>=1:
        a.energy-=1;st["q"]["move_cost"]+=1;a.x=x;a.y=y;a.heading=h;moved=True
    pickup(st,a)
    return moved

def run(seed,s):
    W,H,N,T,LIFE,FEEDS=pars(s);st=init(seed,s);q=st["q"];quarter=T//4
    h=hashlib.sha256(f"NM-SCALE-{s}".encode());qtr=[0,0,0,0];late=False;pos={i:set() for i in range(N)}
    for t in range(T):
        for j in range(FEEDS):
            x=(7*t+3*seed+5*j)%W;y=(11*t+5*seed+1+7*j)%H
            st["material"][x][y]+=1;q["mfeed"]+=1
        for a in st["agents"]:
            if a.formed:
                a.life-=1
                if a.life<=0:dissolve(st,a)
        for a in st["agents"]:
            if a.formed:
                if a.energy>=1:a.energy-=1;q["maint_cost"]+=1
                else:dissolve(st,a)
        for a in st["agents"]:
            move(st,a,t,seed,W,H)
            if t>=quarter:pos[a.id].add((a.x,a.y))
        for a in st["agents"]:
            if energy_active(a.x,a.y,t,seed):a.energy+=2;q["energy_feed"]+=2
        for a in st["agents"]:
            if a.formed:continue
            tr=st["traces"][a.x][a.y].get(a.relation)
            if tr and tr.x==a.x and tr.y==a.y and a.cargo>=3 and a.energy>=3:
                if tr.origin=="DISSOLUTION" and tr.event_id not in st["written"]:q["bad_trace_ref"]+=1
                a.cargo-=3;a.energy-=3;q["form_cost"]+=3;a.formed=True;a.life=LIFE;a.form_x=a.x;a.form_y=a.y;q["formations"]+=1
                if tr.origin=="DISSOLUTION":
                    q["reforms"]+=1
                    if tr.source_agent!=a.id:q["independent_reforms"]+=1
                    if st["transported"].get(tr.event_id,False):q["transported_reforms"]+=1
        for a in st["agents"]:
            if a.formed and demand(a.x,a.y,t)==a.relation and a.energy>=1:
                a.energy-=1;q["work_cost"]+=1;q["work"]+=1;qtr[min(3,t//quarter)]+=1
                if t>=quarter:late=True
        if any(a.energy<0 or a.cargo<0 or a.cargo>3 for a in st["agents"]):q["negative"]+=1
        lm=st["initial_m"]+q["mfeed"];rm=tfree(st)+tcargo(st)+embedded(st)+q["conv_loss"]
        le=st["initial_e"]+q["energy_feed"];re=tenergy(st)+q["move_cost"]+q["form_cost"]+q["maint_cost"]+q["work_cost"]
        if lm!=rm:q["consfail_m"]+=1
        if le!=re:q["consfail_e"]+=1
        h.update((str(t)+":"+str(lm)+":"+str(rm)+":"+str(le)+":"+str(re)+"\n").encode())
    denom=N*T
    return dict(seed=seed,scale=s,hash=h.hexdigest(),q=q,qtr=qtr,late=late,
                unique=statistics.median(len(pos[i]) for i in range(N)),
                work_rate=q["work"]/denom,form_rate=q["formations"]/denom,
                reform_rate=q["reforms"]/denom,ind_rate=q["independent_reforms"]/denom)

def med(x): return statistics.median(x)
def main():
    root=Path(__file__).resolve().parent;rows=[];R={};replay=True
    for s in (1,2,3):
        R[s]=[]
        for seed in range(64):
            a=run(seed,s);b=run(seed,s);replay &= a["hash"]==b["hash"];R[s].append(a);q=a["q"]
            rows.append(dict(scale=s,seed=seed,hash=a["hash"],work=q["work"],formations=q["formations"],
                reforms=q["reforms"],independent_reforms=q["independent_reforms"],transported_reforms=q["transported_reforms"],
                q1=a["qtr"][0],q4=a["qtr"][3],late=a["late"],unique=a["unique"],work_rate=a["work_rate"],
                form_rate=a["form_rate"],reform_rate=a["reform_rate"],ind_rate=a["ind_rate"],
                mfail=q["consfail_m"],efail=q["consfail_e"],negative=q["negative"],bad_trace_ref=q["bad_trace_ref"]))
    with (root/"RAW_RUN_SUMMARY.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    V=dict(material=all(r["q"]["consfail_m"]==0 for rs in R.values() for r in rs),
           energy=all(r["q"]["consfail_e"]==0 for rs in R.values() for r in rs),
           replay=replay,
           negatives=all(r["q"]["negative"]==0 for rs in R.values() for r in rs),
           provenance=all(r["q"]["bad_trace_ref"]==0 for rs in R.values() for r in rs))
    sums={};gates={}
    for s,rs in R.items():
        gates[str(s)]=dict(
            late=sum(r["late"] for r in rs)>=48,
            q4=med([r["qtr"][3] for r in rs])>0,
            independent_seeds=sum(r["q"]["independent_reforms"]>=1 for r in rs)>=48,
            independent_median=med([r["q"]["independent_reforms"] for r in rs])>0,
            transported=sum(r["q"]["transported_reforms"]>=1 for r in rs)>=32,
            movement=med([r["unique"] for r in rs])>1)
        sums[str(s)]=dict(side=17*s,agents=18*s*s,ticks=512*s,life=7*s,feeds=s*s,
            work=med([r["q"]["work"] for r in rs]),forms=med([r["q"]["formations"] for r in rs]),
            reforms=med([r["q"]["reforms"] for r in rs]),independent=med([r["q"]["independent_reforms"] for r in rs]),
            transported=med([r["q"]["transported_reforms"] for r in rs]),
            transported_seeds=sum(r["q"]["transported_reforms"]>=1 for r in rs),
            late_seeds=sum(r["late"] for r in rs),q1=med([r["qtr"][0] for r in rs]),q4=med([r["qtr"][3] for r in rs]),
            unique=med([r["unique"] for r in rs]),work_rate=med([r["work_rate"] for r in rs]),
            form_rate=med([r["form_rate"] for r in rs]),reform_rate=med([r["reform_rate"] for r in rs]),
            ind_rate=med([r["ind_rate"] for r in rs]))
    out=dict(validity=V,gates=gates,summaries=sums,valid=all(V.values()),
             pass_all=all(V.values()) and all(all(g.values()) for g in gates.values()))
    (root/"RESULTS.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
    lines=["# Frozen Carry-Cycle Scale Test — Results","",f"Validity: **{'PASS' if out['valid'] else 'FAIL'}**",
           f"Qualitative scale survival: **{'PASS' if out['pass_all'] else 'FAIL'}**","",
           "| s | side | agents | ticks | life | work | forms | reforms | independent | transported | transported seeds | late seeds | Q1 | Q4 | work rate | unique |",
           "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for s in (1,2,3):
        d=sums[str(s)]
        lines.append(f"| {s} | {d['side']} | {d['agents']} | {d['ticks']} | {d['life']} | {d['work']} | {d['forms']} | {d['reforms']} | {d['independent']} | {d['transported']} | {d['transported_seeds']} | {d['late_seeds']} | {d['q1']} | {d['q4']} | {d['work_rate']:.8f} | {d['unique']} |")
    lines+=["","Scale gates:"]+[f"- s={s}: "+", ".join(f"{k}={'PASS' if v else 'FAIL'}" for k,v in gates[str(s)].items()) for s in (1,2,3)]
    lines+=["","No post-result tuning was performed."]
    (root/"REPORT.md").write_text("\n".join(lines)+"\n")
if __name__=="__main__":main()
