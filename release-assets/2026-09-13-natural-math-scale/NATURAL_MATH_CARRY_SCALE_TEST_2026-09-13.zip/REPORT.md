# Frozen Carry-Cycle Scale Test — Results

Validity: **PASS**
s=1 frozen-baseline sanity: **PASS**
Qualitative scale survival: **PASS**

| scale | side | agents | ticks | life | work | forms | reforms | independent | transported | transported seeds | late-work seeds | Q1 | Q4 | work rate | unique positions |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 17 | 18 | 512 | 7 | 122.0 | 421.0 | 381.5 | 181.5 | 1.0 | 44 | 64 | 47.5 | 22.5 | 0.01323785 | 52.0 |
| 2 | 34 | 72 | 1024 | 14 | 715.5 | 2492.0 | 2341.5 | 996.5 | 6.0 | 64 | 64 | 268.0 | 128.0 | 0.00970459 | 41.5 |
| 3 | 51 | 162 | 1536 | 21 | 2157.0 | 8049.0 | 7679.0 | 2959.0 | 12.0 | 64 | 64 | 769.0 | 422.5 | 0.00866850 | 55.5 |

## Scale gates
- s=1: S1_48_late_work=PASS, S2_q4_positive=PASS, S3_48_independent=PASS, S4_independent_median_positive=PASS, S5_half_transported=PASS, S6_movement=PASS
- s=2: S1_48_late_work=PASS, S2_q4_positive=PASS, S3_48_independent=PASS, S4_independent_median_positive=PASS, S5_half_transported=PASS, S6_movement=PASS
- s=3: S1_48_late_work=PASS, S2_q4_positive=PASS, S3_48_independent=PASS, S4_independent_median_positive=PASS, S5_half_transported=PASS, S6_movement=PASS

## Normalized rates
- s=1: work=0.01323785, formation=0.04568142, reformation=0.04139540, independent=0.01969401, Q4/Q1 median=0.4657
- s=2: work=0.00970459, formation=0.03379991, reformation=0.03175863, independent=0.01351590, Q4/Q1 median=0.4852
- s=3: work=0.00866850, formation=0.03234713, reformation=0.03086018, independent=0.01189156, Q4/Q1 median=0.5443

No post-result tuning was performed.
