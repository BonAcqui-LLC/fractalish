# Scale Test Preregistration v0.1
Validity: material/energy conservation, exact replay, no negatives, trace provenance.
At every scale:
S1 >=48/64 late-work seeds.
S2 median final-quarter work >0.
S3 >=48/64 contributor-independent reformation.
S4 median contributor-independent reformations >0.
S5 >=32/64 transported-substrate reformation.
S6 median distinct positions/agent after first quarter >1.
Report normalized rates. No rescued gates.
