# Carry-Cycle Stability and Local-Condition Audit

Date: 2026-09-13

## 1. Replay stability

For each of the original 64 seeds, the frozen carry mechanism was rerun three times.

- identical transported-reformation count on all three reruns: True
- identical event hash on all three reruns: True

The 44/20 split is therefore deterministic for those seeds, not run-to-run fluctuation.

## 2. Local-condition comparison

Original split:
- transported-success seeds: 44/64
- transported-failure seeds: 20/64

Medians:

| local quantity | success seeds | failure seeds |
|---|---:|---:|
| formed moves | 2.0 | 0.0 |
| transported dissolutions | 2.0 | 0.0 |
| formations | 396.5 | 455.0 |
| reformations | 359.0 | 416.0 |
| contributor-independent reformations | 165.5 | 210.5 |
| mean pre-formation energy | 3.847 | 3.859 |
| fraction formations with energy >=5 | 0.0206 | 0.0187 |
| fraction formed ticks with energy >=2 | 0.0176 | 0.0154 |

Candidate local-condition counts:
- >=1 formed move: success 44/44, failure 6/20
- >=1 transported dissolution: success 44/44, failure 6/20

The clearest necessary local condition is creation of at least one transported dissolution trace. It occurs in all success seeds, but only a minority of failure seeds.

## 3. Seed-count extension

Frozen mechanism, same world and horizon, seeds 0..255.

- transported-success seeds: 171/256
- success rate: 0.6680
- 95% Wilson interval: [0.6082, 0.7228]
- late-work seeds: 256/256
- median total work: 121.0
- median final-quarter work: 22.0

64-seed blocks:
- seeds 0-63: 44/64 = 0.6875
- seeds 64-127: 45/64 = 0.7031
- seeds 128-191: 41/64 = 0.6406
- seeds 192-255: 41/64 = 0.6406

## Interpretation

The shortfall is stable under exact replay and remains a substantial fraction when the seed count is extended. It is not roughly constant in absolute count as more seeds are added, so the evidence does not support an interpretation of a fixed number of exceptional failures.

The strongest local discriminator remains whether a formed structure actually gets transported before dissolution. That condition is necessary but not always sufficient: some failed seeds create transported traces but still lack the energy/material/address conjunction needed for reuse.
