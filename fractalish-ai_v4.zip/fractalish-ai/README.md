# Fractalish AI v0.1

**Fractalish AI is a local-first activation runtime for process-aware AI: it reads form, preserves uncertainty, compares against baselines, and records its reasoning state.**

This is the smallest runnable v0.1 prototype of the Fractalish / Synaptient architecture. It runs fully offline with Python standard library only.

## What it is

- A traceable, stateful, ternary-gated cognition simulator (runtime spine)
- A local demo of PERCEPT → ATAL → RIGOR → CIRCUIT → GUARD → SERA → SessionGlyph
- A Natural Math baseline vs memory-enabled comparison on a grid growth task
- An MCVA / HOLD / AMCVA morphology gate on synthetic samples
- JSON decision records you can inspect, diff, and carry forward

## What it is not

- Not an LLM-from-scratch project
- Not AGI, consciousness, or sentience
- Not an agent army or chatbot skin
- Not medical, legal, financial, or disaster-prediction software
- Not a finished product or certified safety system

## Core doctrine

**Read form carefully. Preserve uncertainty. Compare before claiming.**

## Command checklist

Run from `C:\Users\moop\FractalishBuild\fractalish-ai` (Python 3.10+, stdlib only):

```bash
python examples/demo_natural_math.py          # grid baseline vs memory comparison
python examples/demo_natural_math_v3_6_core.py  # v3.6 closed-system core + oracles
python examples/demo_mcva_gate.py             # MCVA / HOLD / AMCVA gate
python examples/demo_activation.py            # bounded activation state
python examples/demo_full_runtime.py          # full runtime spine
python examples/demo_natural_math_attractor_bias.py      # experimental attractor bias
python examples/demo_natural_math_goal_directed_v3_8.py  # experimental v3.8 goal layer
python examples/demo_generate_investor_packet.py         # investor summary packet
python tests/test_natural_math_v3_6_oracles.py         # v3.6 oracle tests
```

## Quick start

```bash
cd C:\Users\moop\FractalishBuild\fractalish-ai

python examples/demo_activation.py
python examples/demo_natural_math.py
python examples/demo_mcva_gate.py
python examples/demo_full_runtime.py
```

Preview the local demo page:

```bash
python -m http.server 8080
# open http://localhost:8080/public/index.html
```

## Demo flow

1. **demo_activation.py** — start a bounded activation; record guard decision and SessionGlyph hash
2. **demo_natural_math.py** — compare memoryless baseline vs memory-enabled Natural Math
3. **demo_mcva_gate.py** — run synthetic morphology through MCVA / HOLD / AMCVA gate
4. **demo_full_runtime.py** — full spine: Natural Math + MCVA + runtime modules + SessionGlyph export

Outputs land in `outputs/`.

## Architecture (plain language)

| Module | Working definition |
|--------|-------------------|
| **PERCEPT** | Records what arrived: source, modality, confidence, provenance |
| **ATAL** | Tracks pressure (coherence, uncertainty, threat) — does not decide truth |
| **RIGOR** | Checks support, source, contradiction, scope, speculation |
| **CIRCUIT** | Memory routes, open loops, contradiction scars, recovery paths |
| **GUARD** | Single gate: PROCEED, HOLD, REVERSE, or WATCH |
| **SERA** | Cost and waste: runtime, holds, unsupported claims |
| **SessionGlyph** | Carry-forward JSON with deterministic state hash |
| **Natural Math** | Grid growth demo showing memory vs baseline behavior |
| **MCVA** | Morphology structured enough for tentative comparison |
| **HOLD** | Uncertainty preserved; no forced closure |
| **AMCVA** | Guard against over-reading noise or non-diagnostic form |

See [docs/architecture.md](docs/architecture.md) for the full flow diagram.

## Offline operation

- No network calls
- No API keys
- No paid services
- No pip dependencies
- JSON files written to `outputs/`

## Natural Math canon (v0.1)

- **Trunk:** Natural Math v3.6 Core (`fractalish_ai/natural_math/v3_6_core.py`) — closed system per `Natural_math_fixed.txt`
- **Grid demo:** `demo_natural_math.py` — memoryless efficiency trace vs memory-enabled controlled path
- **Experimental branch:** v3.8 goal layer and attractor bias — separate demos, not core, not proof

## Maze benchmark (sandbox)

Maze-running is a controlled benchmark for local decision-making, memory, revisits, traps, and constraint navigation. It is not a claim of general intelligence.

```bash
python experiments/grok_sandbox/benchmark/run_maze_benchmark.py
python experiments/grok_sandbox/maze/maze_runner.py
cd experiments/grok_sandbox/dashboard
python -m http.server 8000
```

See [experiments/grok_sandbox/README.md](experiments/grok_sandbox/README.md) for mode labels and interpretation. Sample traces live in `experiments/grok_sandbox/outputs/sample_maze_runs/` (bulk `maze_runs/` is gitignored).

## Current limitations (v0.1)

- Grid Natural Math demo is a simplified comparison scaffold, separate from v3.6 lattice core
- MCVA uses synthetic 2D grids, not real microscopy or clinical images
- CIRCUIT is in-memory only (no database)
- No LLM integration — this is the runtime spine, not a model
- GUARD rules are minimal heuristics, not learned policies
- SessionGlyph continuity is file-based export/reload, not a live service

## Next milestones

1. Harden GUARD and RIGOR with the Cognitive Basin demo scenarios (false continuity, contradiction scar, recovery route)
2. Port fuller Natural Math profiles from the reference implementation
3. Add real image morphology pipeline (rule-based analyzer)
4. Package offline Android demo
5. Add MCVA dataset registry and domain baselines

## Repository layout

```
fractalish-ai/
  fractalish_ai/       # Python runtime package
  examples/            # Runnable demos
  experiments/grok_sandbox/  # Maze benchmark (isolated)
  schemas/             # JSON schemas
  docs/                # Architecture, non-claims, test plan
  public/              # Static local demo page
  outputs/             # Generated outputs (mostly gitignored; regenerate via demos)
```

## Documentation

- [docs/non_claims.md](docs/non_claims.md) — what this prototype does not claim
- [docs/investor_demo_notes.md](docs/investor_demo_notes.md) — demo pitch and milestones
- [docs/test_plan.md](docs/test_plan.md) — comparison methodology
- [LICENSE_PENDING.md](LICENSE_PENDING.md) — license status

## Reference canon

Built from staged reference materials at `C:\Users\moop\FractalishBuild\reference`.